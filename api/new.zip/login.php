<?php
require 'db.php';
require 'jwt_config.php';

header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"));
$email = trim($data->email ?? '');
$password = trim($data->password ?? '');

if (empty($email) || empty($password)) {
    echo json_encode(["status" => "failed", "message" => "Email and password are required"]);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(["status" => "failed", "message" => "Invalid email format"]);
    exit;
}

$stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user && password_verify($password, $user['password'])) {
    $token = createJWT($user['id']);
    echo json_encode(["status" => "success", "user" => $user, "token" => $token]);
} else {
    echo json_encode(["status" => "failed", "message" => "Invalid credentials"]);
}
