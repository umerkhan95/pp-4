<?php
require 'db.php';
require 'jwt_config.php';

header('Content-Type: application/json');

$headers = getallheaders();
$auth = $headers['Authorization'] ?? '';
$token = str_replace('Bearer ', '', $auth);

$decoded = validateJWT($token);
$user_id = $decoded->user_id ?? null;

if (!$user_id) {
    echo json_encode(["status" => "failed", "message" => "Invalid or missing token"]);
    exit;
}

$device_id = $_GET['device_id'] ?? '';
if (!$device_id) {
    echo json_encode(["status" => "failed", "message" => "Missing device_id"]);
    exit;
}

// Optional: Verify device belongs to the user
$stmt = $conn->prepare("SELECT id FROM devices WHERE id = ? AND user_id = ?");
$stmt->execute([$device_id, $user_id]);
if ($stmt->rowCount() === 0) {
    echo json_encode(["status" => "failed", "message" => "Unauthorized or unknown device"]);
    exit;
}

// Fetch latest device status
$stmt = $conn->prepare("SELECT * FROM device_status WHERE device_id = ?");
$stmt->execute([$device_id]);
$status = $stmt->fetch(PDO::FETCH_ASSOC);

if ($status) {
    echo json_encode([
        "status" => "success",
        "data" => $status
    ]);
} else {
    echo json_encode([
        "status" => "not_found",
        "message" => "No status found for this device"
    ]);
}
?>
