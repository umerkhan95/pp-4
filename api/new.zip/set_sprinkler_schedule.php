<?php
require 'db.php';
require 'jwt_config.php';

header('Content-Type: application/json');

try {
    // Validate token
    $headers = getallheaders();
    $auth = $headers['Authorization'] ?? '';
    if (!$auth) {
        throw new Exception("Authorization header missing");
    }

    $token = str_replace('Bearer ', '', $auth);
    $decoded = validateJWT($token);
    $user_id = $decoded->user_id ?? null;

    if (!$user_id) {
        echo json_encode(["status" => "failed", "message" => "Invalid token payload"]);
        exit;
        // throw new Exception("Invalid token payload");
    }

    // Validate JSON input
    $data = json_decode(file_get_contents("php://input"));
    if (!$data || !isset($data->device_id) || !isset($data->times) || !is_array($data->times)) {
        // throw new Exception("Missing or invalid 'device_id' or 'times'");
        echo json_encode(["status" => "failed", "message" => "Missing or invalid 'device_id' or 'times'"]);
        exit;
    }

    $device_id = $data->device_id;
    $times = $data->times;

    // Delete previous schedule
    $conn->prepare("DELETE FROM sprinkler_schedule WHERE device_id = ?")->execute([$device_id]);

    // Insert new schedule
    $stmt = $conn->prepare("INSERT INTO sprinkler_schedule (device_id, time_slot) VALUES (?, ?)");
    foreach ($times as $time) {
        if (!is_string($time)) {
            echo json_encode(["status" => "failed", "message" => "Missing or invalid 'device_id' or 'times'"]);
            exit;
        }
        $stmt->execute([$device_id, $time]);
    }
    // Fetch newly inserted schedule
    $fetchStmt = $conn->prepare("SELECT time_slot FROM sprinkler_schedule WHERE device_id = ?");
    $fetchStmt->execute([$device_id]);
    $schedule = $fetchStmt->fetchAll(PDO::FETCH_COLUMN);

    echo json_encode(["status" => "schedule_updated", "data" => ["device_id" => $device_id, "schedule" => $schedule]]);
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(["status" =>"failed", "error" => $e->getMessage()]);
}
